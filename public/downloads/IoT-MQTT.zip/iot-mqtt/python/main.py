from arduino.app_utils import App

# Todo el MQTT vive en el sketch (sketch/sketch.ino).
App.run()
