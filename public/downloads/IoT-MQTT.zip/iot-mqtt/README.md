# 😀 IoT-MQTT




# 📡 IoT-MQTT · Curso IoT CIDESI

App para el **Arduino UNO Q** que envía lecturas a un broker MQTT y recibe comandos desde el dashboard del curso.
Todo el código vive en el sketch (`sketch/sketch.ino`); `python/main.py` no hace nada.

## Antes de empezar

1. **WiFi con salida a internet.** Desde la terminal de la placa en App Lab:

   ```bash
   nmcli device wifi list
   sudo nmcli device wifi connect "NOMBRE_DE_LA_RED" password "CONTRASEÑA"
   nmcli device status
   ```

   `wlan0` debe aparecer como `connected`. La placa recuerda la red.

2. **Librerías.** Están declaradas en `sketch/sketch.yaml` y App Lab las descarga al presionar **Run**:
   `PubSubClient (2.8.0)` y `ArduinoJson (7.4.3)`.

## Broker MQTT

| Dato | Valor |
| --- | --- |
| Host | `100.48.65.94` |
| Puerto | `1883` (MQTT por TCP, sin cifrado) |
| Usuario / contraseña | Ninguno (acceso anónimo) |
| Dashboard (navegador) | `wss://curso-iot-broker-100-48-65-94.sslip.io` |

## Identificador de la placa

Se calcula con el número de serie del microcontrolador, así que es único y no cambia: `unoq-xxxxxxxx`.
Al presionar **Run** aparece en el monitor serial:

```
Tu identificador: unoq-0fb74d07
MQTT conectado. Escribe en el dashboard: unoq-0fb74d07
```

Escribe ese identificador en el dashboard para ver tus datos.

## Tópicos

| Tópico | Dirección | Contenido |
| --- | --- | --- |
| `devices/<id>/telemetry` | placa → dashboard | JSON cada 3 s |
| `devices/<id>/status` | placa → broker | `ONLINE` / `OFFLINE` retenido (última voluntad) |
| `devices/<id>/cmd` | dashboard → placa | Comandos JSON (QoS 1) |

## Comandos

| JSON | Efecto |
| --- | --- |
| `{"led": true}` | Enciende (o apaga con `false`) toda la matriz |
| `{"color": "#ff0080"}` | Color en los LEDs RGB 3 y 4 |
| `{"matrix": ["0001100011000", ...]}` | Dibujo: 8 filas de 13 caracteres, `1` = LED encendido |

La placa confirma cada comando reportando `led`, `color` y `matrix` en su telemetría:

```json
{
  "device_id": "unoq-0fb74d07",
  "temperatura": 24.3,
  "humedad": 51.8,
  "led": true,
  "color": "#ff0080",
  "matrix": ["0000000000000", "..."]
}
```

## Cómo se conecta

El WiFi pertenece al lado Linux de la placa. El sketch abre la conexión TCP a través del **Bridge** con
`BridgeTCPClient` (hace el papel del `WiFiClient` de un ESP32) y `PubSubClient` habla MQTT sobre ella.

## Si algo falla

- **"No se pudo abrir el socket al broker"**: revisa el WiFi con `nmcli device status`.
- **"Fallo MQTT, rc=…"**: el broker rechazó o no respondió; la placa reintenta cada 5 s.
- **No aparecen datos en el dashboard**: confirma que escribiste el identificador exacto del monitor serial.
