#include <Arduino_RouterBridge.h>
#include <Arduino_LED_Matrix.h>
#include <PubSubClient.h>
#include <ArduinoJson.h>

// 1. Broker MQTT del curso
const char* MQTT_BROKER = "100.48.65.94";
const int   MQTT_PORT   = 1883;

// 2. Identificador único de la placa: se calcula con el número de serie
//    del microcontrolador (96 bits) y se imprime en el monitor serial.
String chipId() {
  const volatile uint32_t* uid = (const volatile uint32_t*)0x0BFA0700;  // UID del STM32U585
  uint32_t hash = 2166136261UL;
  for (int i = 0; i < 3; i++) {
    uint32_t word = uid[i];
    for (int b = 0; b < 4; b++) {
      hash ^= (word >> (8 * b)) & 0xFF;
      hash *= 16777619UL;
    }
  }
  char buf[16];
  snprintf(buf, sizeof(buf), "unoq-%08lx", (unsigned long)hash);
  return String(buf);
}

String DEVICE_ID = chipId();

String topicTelemetry = String("devices/") + DEVICE_ID + "/telemetry";
String topicStatus    = String("devices/") + DEVICE_ID + "/status";
String topicCmd       = String("devices/") + DEVICE_ID + "/cmd";

// El WiFi lo tiene el lado Linux de la placa: el socket TCP viaja por el Bridge
BridgeTCPClient<> net(Bridge);
PubSubClient mqtt(net);
Arduino_LED_Matrix matrix;

// Matriz de 8 x 13 = 104 LEDs azules (1 = encendido, 0 = apagado)
const int FILAS = 8;
const int COLUMNAS = 13;
uint8_t frame[FILAS * COLUMNAS];

String color = "#000000";
bool publishNow = false;
unsigned long lastPublish = 0;
unsigned long lastAttempt = 0;

bool matrixOn() {
  for (int i = 0; i < FILAS * COLUMNAS; i++) {
    if (frame[i]) return true;
  }
  return false;
}

// Interruptor del dashboard: {"led": true} enciende toda la matriz
void fillMatrix(uint8_t value) {
  for (int i = 0; i < FILAS * COLUMNAS; i++) frame[i] = value;
  matrix.draw(frame);
}

// Dibujo del dashboard: {"matrix": ["0001100011000", ...]}
// 8 filas de 13 caracteres, '1' = LED encendido
bool drawRows(JsonArray rows) {
  if (rows.size() != FILAS) return false;
  for (int r = 0; r < FILAS; r++) {
    const char* row = rows[r] | "";
    if (strlen(row) != COLUMNAS) return false;
  }
  for (int r = 0; r < FILAS; r++) {
    const char* row = rows[r];
    for (int c = 0; c < COLUMNAS; c++) {
      frame[r * COLUMNAS + c] = row[c] == '1' ? 1 : 0;
    }
  }
  matrix.draw(frame);
  return true;
}

bool isHexColor(const char* s) {
  if (strlen(s) != 7 || s[0] != '#') return false;
  for (int i = 1; i < 7; i++) {
    if (!isxdigit(s[i])) return false;
  }
  return true;
}

// Color del dashboard: {"color": "#ff0080"}
void setRgb(const char* hex) {
  long v = strtol(hex + 1, nullptr, 16);
  int r = (v >> 16) & 0xFF;
  int g = (v >> 8) & 0xFF;
  int b = v & 0xFF;

  // LED 3 tiene PWM: mezcla cualquier color
  analogWrite(LED3_R, r);
  analogWrite(LED3_G, g);
  analogWrite(LED3_B, b);

  // LED 4 solo enciende o apaga cada canal y es activo en LOW
  digitalWrite(LED4_R, r > 127 ? LOW : HIGH);
  digitalWrite(LED4_G, g > 127 ? LOW : HIGH);
  digitalWrite(LED4_B, b > 127 ? LOW : HIGH);

  color = hex;
  color.toLowerCase();
}

void onMessage(char* topic, byte* payload, unsigned int length) {
  JsonDocument doc;
  if (deserializeJson(doc, payload, length)) {
    Monitor.println("Comando ignorado, no es JSON");
    return;
  }

  if (doc["led"].is<bool>()) {
    fillMatrix(doc["led"] ? 1 : 0);
    publishNow = true;
  }

  const char* hex = doc["color"] | "";
  if (isHexColor(hex)) {
    setRgb(hex);
    publishNow = true;
  }

  if (doc["matrix"].is<JsonArray>() && drawRows(doc["matrix"].as<JsonArray>())) {
    publishNow = true;
  }
}

bool connectMQTT() {
  // BridgeTCPClient devuelve 0 al conectar (no 1 como WiFiClient):
  // abrimos el socket primero y PubSubClient lo reutiliza
  if (!net.connected() && net.connect(MQTT_BROKER, MQTT_PORT) < 0) {
    Monitor.println("No se pudo abrir el socket al broker");
    return false;
  }

  String clientId = String("unoq-") + DEVICE_ID + "-" + String(random(0xffff), HEX);
  String offline  = String("{\"device_id\":\"") + DEVICE_ID + "\",\"estado\":\"OFFLINE\"}";

  // Última voluntad (LWT): si la placa se desconecta, el broker publica OFFLINE
  if (!mqtt.connect(clientId.c_str(), topicStatus.c_str(), 1, true, offline.c_str())) {
    Monitor.print("Fallo MQTT, rc=");
    Monitor.println(mqtt.state());
    net.stop();
    return false;
  }

  String online = String("{\"device_id\":\"") + DEVICE_ID + "\",\"estado\":\"ONLINE\"}";
  mqtt.publish(topicStatus.c_str(), online.c_str(), true);
  mqtt.subscribe(topicCmd.c_str(), 1);
  Monitor.print("MQTT conectado. Escribe en el dashboard: ");
  Monitor.println(DEVICE_ID);
  publishNow = true;
  return true;
}

void publishTelemetry() {
  JsonDocument doc;
  doc["device_id"]   = DEVICE_ID;
  doc["temperatura"] = 20.0 + random(0, 100) / 10.0;  // reemplaza con tu sensor
  doc["humedad"]     = 40.0 + random(0, 200) / 10.0;

  // Estado real de la placa: así el dashboard confirma cada comando
  doc["led"]   = matrixOn();
  doc["color"] = color;
  JsonArray rows = doc["matrix"].to<JsonArray>();
  for (int r = 0; r < FILAS; r++) {
    char row[COLUMNAS + 1];
    for (int c = 0; c < COLUMNAS; c++) row[c] = frame[r * COLUMNAS + c] ? '1' : '0';
    row[COLUMNAS] = '\0';
    rows.add(row);
  }

  char payload[400];
  serializeJson(doc, payload);
  mqtt.publish(topicTelemetry.c_str(), payload);
}

void setup() {
  Bridge.begin();
  net.begin();
  Monitor.begin(115200);

  Monitor.print("Tu identificador: ");
  Monitor.println(DEVICE_ID);

  matrix.begin();
  matrix.setGrayscaleBits(1);
  fillMatrix(0);

  pinMode(LED4_R, OUTPUT);
  pinMode(LED4_G, OUTPUT);
  pinMode(LED4_B, OUTPUT);
  setRgb("#000000");

  mqtt.setServer(MQTT_BROKER, MQTT_PORT);
  mqtt.setBufferSize(512);  // la telemetría con la matriz pasa de 256 bytes
  mqtt.setCallback(onMessage);
}

void loop() {
  if (!mqtt.connected()) {
    if (millis() - lastAttempt >= 5000) {
      lastAttempt = millis();
      connectMQTT();
    }
    return;
  }
  mqtt.loop();

  if (publishNow || millis() - lastPublish >= 3000) {
    publishNow = false;
    lastPublish = millis();
    publishTelemetry();
  }
}
